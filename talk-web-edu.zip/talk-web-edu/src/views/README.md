	
### 项目目录说明
```
.
|-- src                             		// 源码目录
|   |-- views                         		
|       |-- index.vue                	// 板块名称：首页,功能：首页,路由：localhost:xxxx,组件及插件使用：
|      
.
```


