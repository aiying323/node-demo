# 主题列表
1、base.scss 该scss文件中主要用于清除默认样式，指定基础样式，例如font-family、背景之类的
2、theme/small 小学样式
3、theme/middle 初中样式
4、theme/high 高中样式
5、mixin.scss 该scss文件中主要定义公共函数
	函数列表，函数名及用法
6、animation 该scss文件中主要定义公共动画
	动画列表，动画名及用法



