export default function(router, store) {
  router.beforeEach((to, from, next)=>{
    next();
  })
}
