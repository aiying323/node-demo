//获取内核版本
export function getName(name) {
 
  return name
}