'use strict'
module.exports = {
  THEME: JSON.stringify({
    VERSION: '1.0.0',
    LIST: ['small', 'middle', 'high'],
    PATH: './src/scss/theme/',
    HREF: 'css/theme/'
  })
}
