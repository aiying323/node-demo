'use strict'
module.exports = {
  NODE_ENV: '"development"',
	http: JSON.stringify({
    root: 'http://192.168.2.105:8081', //请求路径
    appId: '', //微信授权id
	})
}
